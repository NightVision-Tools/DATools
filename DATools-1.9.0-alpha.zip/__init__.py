"""Init DATools"""

bl_info = {
    "name": "DATools",
    "author": "Tinazzi Patrick",
    "version": (1, 9, 0),
    "blender": (5, 1, 0),
    "location": "View3D > Sidebar > DAT",
    "description": "A set of tools for the DungeonAlchemist™ import pipeline",
    "category": "3D View",
}

import os
import sys
import types

import bpy

if __package__ is None:
    addon_name = os.path.basename(os.path.dirname(__file__))
    addon_path = os.path.dirname(__file__)
    parent_dir = os.path.dirname(addon_path)
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)
    if addon_name not in sys.modules:
        package_module = types.ModuleType(addon_name)
        package_module.__path__ = [addon_path]
        sys.modules[addon_name] = package_module
    __package__ = addon_name

ADDON_MODULE = __package__ or __name__

from . import dictionary

dictionary.set_addon_module(ADDON_MODULE)

from .dictionary import (
    get_language_items,
    get_language_display,
    register_translations,
    translate,
    unregister_translations,
)
from .ui.main_panel import (
    DAT_3DV_MainPanel,
    DAT_MainPanelState,
    DAT_OT_MainPanelExpand,
    DAT_OT_MainPanelPin,
    DAT_OT_MainPanelPreviewHello,
    DAT_OT_MainPanelSelect,
    register_custom_icons,
    register_scene_properties,
    unregister_custom_icons,
)
from .ui.select_language import DAT_OP_SelectLanguage
from .operators.floor_it import DAT_OP_FloorIt
from .operators.rez_it import DAT_OP_RezIt
from .operators.scale_it import DAT_OP_ScaleIt
from .operators.mirror_it import DAT_OP_Mirrorit
from .operators.shrink_it import DAT_OP_ShrinkIt
from .operators.map_it import DAT_OP_MapIt
from .operators.custom_scripts import (
    DAT_CustomScriptItem,
    DAT_OT_CustomScriptAdd,
    DAT_OT_CustomScriptDisplayToggle,
    DAT_OT_CustomScriptEdit,
    DAT_OT_CustomScriptIcon,
    DAT_OT_CustomScriptMove,
    DAT_OT_CustomScriptRename,
    DAT_OT_CustomScriptRemove,
    DAT_OT_CustomScriptToggle,
    draw_custom_scripts_settings,
    register_enabled_custom_scripts,
    unregister_custom_scripts,
)


class DAToolsPreferences(bpy.types.AddonPreferences):
    bl_idname = ADDON_MODULE
    bl_label = "DATools Preferences"

    language: bpy.props.StringProperty(
        name="Language",
        default="ENGLISH",
    )
    custom_scripts: bpy.props.CollectionProperty(type=DAT_CustomScriptItem)

    def draw(self, context):
        layout = self.layout
        layout.label(text=translate("addon_language_header", context))
        layout.label(
            text=str(translate("selected_language_text", context)).format(
                get_language_display(self.language)
            )
        )

        row = layout.row()
        row.operator("dat.select_language", text=translate("language_option_english", context)).language = "ENGLISH"
        row.operator("dat.select_language", text=translate("language_option_italian", context)).language = "ITALIAN"

        row = layout.row()
        row.operator("dat.select_language", text=translate("language_option_german", context)).language = "GERMAN"
        row.operator("dat.select_language", text=translate("language_option_french", context)).language = "FRENCH"

        draw_custom_scripts_settings(layout, context)
        _draw_icon_viewer_preferences(layout, context)


def _get_icon_viewer_addon(context):
    addon = context.preferences.addons.get("bl_ext.blender_org.icon_viewer")
    if addon is not None:
        return addon

    for addon_key in context.preferences.addons.keys():
        if addon_key.endswith(".icon_viewer") or addon_key == "icon_viewer":
            addon = context.preferences.addons.get(addon_key)
            if addon is not None:
                return addon

    return None


def _draw_prop_if_exists(layout, data, prop_name):
    if hasattr(data, prop_name):
        layout.prop(data, prop_name)


def _draw_icon_viewer_preferences(layout, context):
    box = layout.box()
    box.label(text="Icon Viewer Preferences", icon="FILE_IMAGE")

    addon = _get_icon_viewer_addon(context)
    if addon is None:
        box.label(text="Icon Viewer add-on not enabled: bl_ext.blender_org.icon_viewer", icon="INFO")
        return

    prefs = addon.preferences

    try:
        box.operator("iv.icons_show", icon="VIEWZOOM")
    except Exception:
        pass

    row = box.row()

    col = row.column(align=True)
    col.label(text="Icons:")
    _draw_prop_if_exists(col, prefs, "show_matcap_icons")
    _draw_prop_if_exists(col, prefs, "show_brush_icons")
    _draw_prop_if_exists(col, prefs, "show_colorset_icons")
    _draw_prop_if_exists(col, prefs, "show_event_icons")
    col.separator()
    _draw_prop_if_exists(col, prefs, "show_history")

    col = row.column(align=True)
    col.label(text="Popup:")
    _draw_prop_if_exists(col, prefs, "auto_focus_filter")
    _draw_prop_if_exists(col, prefs, "copy_on_select")
    if getattr(prefs, "copy_on_select", False):
        _draw_prop_if_exists(col, prefs, "close_on_select")

    col = row.column(align=True)
    col.label(text="Panel:")
    _draw_prop_if_exists(col, prefs, "show_panel")
    if getattr(prefs, "show_panel", False):
        _draw_prop_if_exists(col, prefs, "show_panel_icons")

    col.separator()
    col.label(text="Header:")
    _draw_prop_if_exists(col, prefs, "show_header")


# register classes
classes = (
    DAT_CustomScriptItem,
    DAToolsPreferences,
    DAT_OP_SelectLanguage,
    DAT_OT_CustomScriptAdd,
    DAT_OT_CustomScriptRemove,
    DAT_OT_CustomScriptEdit,
    DAT_OT_CustomScriptRename,
    DAT_OT_CustomScriptIcon,
    DAT_OT_CustomScriptMove,
    DAT_OT_CustomScriptDisplayToggle,
    DAT_OT_CustomScriptToggle,
    DAT_OP_FloorIt,
    DAT_OP_RezIt,
    DAT_OP_ScaleIt,
    DAT_OP_Mirrorit,
    DAT_OP_ShrinkIt,
    DAT_OP_MapIt,
    DAT_MainPanelState,
    DAT_OT_MainPanelSelect,
    DAT_OT_MainPanelExpand,
    DAT_OT_MainPanelPin,
    DAT_OT_MainPanelPreviewHello,
    DAT_3DV_MainPanel,
)


def register():
    register_custom_icons()

    for cls in classes:
        bpy.utils.register_class(cls)

    register_translations()
    register_scene_properties()
    register_enabled_custom_scripts()


def unregister():
    unregister_custom_scripts()
    unregister_translations()

    for prop in (
        "dat_panel_state",
        "ui_menu",
        "dat_textureresolution",
        "dat_scale",
        "dat_mirror",
        "dat_shrinkpercentage",
        "dat_shrink_mode",
        "dat_shrink_apply_modifiers",
        "dat_shrink_select_result",
        "dat_location_x",
        "dat_location_y",
        "dat_location_z",
        "dat_rotation_x",
        "dat_rotation_y",
        "dat_rotation_z",
        "dat_scale_x",
        "dat_scale_y",
        "dat_scale_z",
        "dat_scalebuffer",
        "dat_activeobjectbuffer",
    ):
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    unregister_custom_icons()

